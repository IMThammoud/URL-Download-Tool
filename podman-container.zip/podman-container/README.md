# My Youtube Downloader 

- Contains:
- the .JAR (Packaged SpringBoot app)
- The yt-tlp binary 
- Dockerfile to build the image and run a Container
- To run this as a podman container:
-- Build Step: " podman build -t myimage:1.0 . "
-- Run Container: " podman run -p 8080:8080 'ID of IMAGE'  "

The app will be accessable on localhost:8080 where you can type in a URL to download a video.
